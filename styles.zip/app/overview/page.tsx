import StationMapOverview from "@/components/overview/StationMapOverview"

export default function OverviewPage() {
  return <StationMapOverview />
}
