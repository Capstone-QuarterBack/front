import UserManagement from "@/components/users/UserManagement";

export default function UsersPage() {
  return <UserManagement />;

  
}
