import StatisticsPage from "@/components/statistics/StatisticsPage"

export default function StatisticsRoute() {
  return <StatisticsPage />
}
