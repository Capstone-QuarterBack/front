export const API_BASE_URL = "http://localhost:8080/api"

// 웹소켓 URL 추가
export const WEBSOCKET_URL = "ws://localhost:8080/react"
