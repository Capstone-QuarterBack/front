import TransactionHistory from "@/components/transactions/TransactionHistory"

export default function TransactionsPage() {
  return <TransactionHistory />
}
