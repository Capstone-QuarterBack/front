"use client"

import StationDetailPage from "@/components/overview/StationDetailPage"

export default function StationDetailPageWrapper() {
  return <StationDetailPage />
}
